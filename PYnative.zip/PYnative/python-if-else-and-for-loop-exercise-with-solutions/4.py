COUNT_ROWS = 10
num = int(input('Enter a number: '))
for i in range(COUNT_ROWS):
    print((i+1) * num)