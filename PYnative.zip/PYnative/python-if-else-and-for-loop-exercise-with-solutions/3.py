num = int(input('Enter number: '))
sum = 0
for i in range(num):
    sum += i + 1

print ('Sum is:', sum)