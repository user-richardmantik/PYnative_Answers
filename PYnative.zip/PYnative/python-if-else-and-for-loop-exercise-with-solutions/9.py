COUNT_ROWS = 10
for num in range(COUNT_ROWS, 0, -1):
    print (-1*(num))