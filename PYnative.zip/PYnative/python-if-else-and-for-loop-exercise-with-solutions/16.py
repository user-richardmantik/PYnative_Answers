input_number = int(input('input_number = '))
for i in range (0,input_number):
    print ('Current Number is :', (i+1), 'and the cube is', (i+1)**3)