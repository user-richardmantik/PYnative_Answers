for i in range(5):
    print(i)
else:
    print('Done!')