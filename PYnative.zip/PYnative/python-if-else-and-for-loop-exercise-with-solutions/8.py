numbers_list = [10, 20, 30, 40, 50]
for num in reversed(numbers_list):
    print(num)