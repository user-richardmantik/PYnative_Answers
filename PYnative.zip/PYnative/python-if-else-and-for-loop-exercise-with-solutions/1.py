COUNT_ROWS = 10
i = 0
while(i < COUNT_ROWS):
    print(i+1)
    i+=1
