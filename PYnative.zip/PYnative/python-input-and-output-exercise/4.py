num = 458.541315

print ('{:.2f}'.format(num))