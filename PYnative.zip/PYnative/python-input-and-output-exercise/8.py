total_money = 1000
quantity = 3
price = 450
line = 'I have {0:d} dollars so I can buy {1:d} football for {2:.2f} dollars.'
print (line.format(total_money, quantity, price))