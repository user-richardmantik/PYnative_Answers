lines = input('Enter three string ').split()
i = 0
for line in lines:
    print ('Name' , i, ': ', line, sep = '')
    i+=1