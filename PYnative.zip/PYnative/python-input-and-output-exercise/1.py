num_1 = int(input('Enter first number: '))
num_2 = int(input('Enter second number: '))

print ('Multiplication is', num_1*num_2)