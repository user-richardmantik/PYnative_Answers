my_list = range (1, 11)
z = 0
for i in range(0, 4):
    line = ''
    for j in range (0, i+1):
        line = str(my_list[z]) + (' ' if (j > 0) else '') + line
        z += 1
    print (line)