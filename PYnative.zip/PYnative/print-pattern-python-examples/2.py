i = 1
while (i <= 5):
    line = '';
    j = 1;
    while (j <= i):
        line += (' ' if (j > 1) else '') + str(j)
        j += 1
    print(line)
    i += 1