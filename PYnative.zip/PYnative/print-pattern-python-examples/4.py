i = 5
while (i >= 1):
    line = ''
    j = 1
    while (j <= i):
        line += (' ' if (j > 1) else '') + str(5)
        j += 1
    print(line)
    i -= 1
