for i in range(1, 6):
    line = ''
    for j in range(1, i+1):
        line = str(j) + (' ' if (j > 1) else '') + line
    print (line)