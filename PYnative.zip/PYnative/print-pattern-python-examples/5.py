count_rows = 5

for i in range(count_rows, 0, -1):
    line = ''
    for j in range(0, i+1, 1):
        line += (' ' if (j >= 1) else '') + str(j)
    print (line)