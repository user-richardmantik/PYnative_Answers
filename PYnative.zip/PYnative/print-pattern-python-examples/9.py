for i in range (5, 0, -1):
    line = ''
    for j in range (i, 0, -1):
        line += (' ' if (j < i) else '') + str(j)
    print (line)