for i in range (1, 6):
    line_list = list()
    z = None
    for j in range (1, i+1):
        line_list.append(str(j))
        z = j
    for j in range(z, 5):
        line_list.insert(0, ' ')
    line = ' '.join(line_list)
    print(line)