i = 1
while i <= 5:
    line = ''
    j = 1
    while (j <= i):
        line = line + (' ' if (j > 1) else '') + str(i)
        j += 1
    i += 1
    print(line)