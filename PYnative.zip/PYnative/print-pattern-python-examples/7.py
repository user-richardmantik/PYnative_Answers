for i in range(5, 0, -1):
    line = ''
    for j in range(0, i):
        line += (' ' if (j > 0) else '') + str(i)
    print (line)