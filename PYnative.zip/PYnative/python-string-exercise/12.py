input_str = 'Emma is a data scientist who knows Python. Emma works at google.'
search_str = 'Emma'
print('Last occurrence of', search_str, 'starts at index', input_str.rfind(search_str))