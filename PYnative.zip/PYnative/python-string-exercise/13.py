input_str = 'Emma-is-a-data-scientist'
input_list = input_str.split('-')

for s in input_list:
    print(s)