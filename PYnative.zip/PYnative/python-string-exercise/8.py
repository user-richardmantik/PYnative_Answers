input_str = 'Welcome to USA. usa awesome, isn\'t it?'
search_str = 'USA'

print ('The', search_str, 'count is:', input_str.lower().count(search_str.lower()))