input_str = 'PYnative'
print(input_str[::-1])