def exponent(base, exp):
    print(base, "raises to the power of", exp, "is: ", base ** exp)

base = 5
exp = 4

exponent(base, exp)