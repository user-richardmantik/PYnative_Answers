for num_1 in range (1, 11):
    print("{0:<2d}".format(num_1), end=' ')
    for num_2 in range (2, 11):
        print(num_1 * num_2, end=' ')
    print()