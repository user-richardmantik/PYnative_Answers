orig_str = 'pynative'
print ('Printing only even index chars')
for i in range(len(orig_str)):
    if (i % 2 == 0): print (orig_str[i])