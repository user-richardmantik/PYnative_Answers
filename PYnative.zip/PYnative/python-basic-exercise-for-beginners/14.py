for num_1 in range (5, 0, -1):
    for num_2 in range(0, num_1):
        print ('*', end=' ')
    print()