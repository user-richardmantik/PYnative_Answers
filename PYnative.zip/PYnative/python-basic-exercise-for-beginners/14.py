COUNT_ROWS = 5
for i in range (COUNT_ROWS, 0, -1):
    for j in range(0, i):
        print ('*', end=' ')
    print()