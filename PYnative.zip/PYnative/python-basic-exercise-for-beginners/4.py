def remove_chars(word, n):
    return word[n:len(word)]

print("Removing characters from a string")
print(remove_chars("pynative", 4))
print(remove_chars("pynative", 2))