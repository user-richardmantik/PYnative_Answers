str_x = "Emma is good developer. Emma is a writer"
print ('Emma appeared', str_x.count('Emma'), 'times') 