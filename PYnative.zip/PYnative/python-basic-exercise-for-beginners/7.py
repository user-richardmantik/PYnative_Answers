str_1 = "Emma is good developer. Emma is a writer"
print ('Emma appeared', str_1.count('Emma'), 'times') 