num_1 = 40
num_2 = 30
ret_val = (num_1 * num_2) if (num_1 * num_2 <= 1000) else (num_1+num_2)
print ('The result is ' + str(ret_val))