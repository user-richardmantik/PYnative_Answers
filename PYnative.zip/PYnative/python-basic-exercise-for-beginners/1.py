number1 = 40
number2 = 30
ret_val = (number1 * number2) if (number1 * number2 <= 1000) else (number1+number2)
print ('The result is ' + str(ret_val))